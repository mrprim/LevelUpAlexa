const src = require('./src')

exports.handler = src.handler
