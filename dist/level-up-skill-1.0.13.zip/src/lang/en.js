module.exports = {
  translation: {
    SKILL_NAME: 'Level Up',
    LAUNCH_PROMPT: 'Oh?  Alright, let\'s play Level Up!',
    HELP_MESSAGE: 'Need help?',
    HELP_REPROMPT: 'What can I help you with?',
    STOP_MESSAGE: 'Goodbye!'
  }
}
