const en = require('./en')

module.exports = {
  en: en
}
