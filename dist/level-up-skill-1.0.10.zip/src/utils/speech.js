function emphasize (str) {
  return '<emphasis level="strong">' + str + '</emphasis>'
}

module.exports = {
  emphasize: emphasize
}
