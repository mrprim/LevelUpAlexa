module.exports = function () {
  const events = this.attributes['events'] || []
  const sb = events.reduce((sb, event) => sb[event.type]++, {})
  this.response.speak('You have been on ' + events.length + ' adventures.  You have fought ' + sb.combat + ' monsters.  You have looted ' + sb.treasure + 'treasures!')
  this.shouldEndSession = false
  this.emit(':responseReady')
}
